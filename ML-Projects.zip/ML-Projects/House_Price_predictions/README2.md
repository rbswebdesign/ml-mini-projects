# House Price Prediction using Machine Learning

## 📌 Project Overview
This project predicts house prices based on various property features using a supervised machine learning model.  
The goal is to assist buyers, sellers, and real estate agents in estimating property prices accurately.

## 🛠️ Tools & Technologies
- **Programming Language:** Python
- **Libraries:** pandas, numpy, matplotlib, seaborn, scikit-learn
- **Algorithm:** Linear Regression (best performing model)

## 📂 Dataset
The dataset includes property-related details such as:
- Number of Rooms
- Square Footage
- Location
- Year Built
- Condition
- Other relevant features
- Target: House Price

## ⚙️ Approach
1. **Data Preprocessing**
   - Handle missing values
   - Encode categorical variables
   - Feature scaling
2. **Model Selection**
   - Tested multiple regression models
   - Selected Linear Regression for best performance
3. **Evaluation**
   - Mean Absolute Error (MAE)
   - Root Mean Squared Error (RMSE)
   - R² Score
   - Visualizations for actual vs predicted prices

## 📈 Model Performance
- **R² Score:** 0.92 (example, replace with your value)
- Plots such as the accuracy chart are included in the repository.

![Accuracy Chart](accuracy_chart.png)

## 🚀 How to Run
```bash
# Clone the repository
git clone https://github.com/yourusername/house_price_prediction.git

# Navigate to the project folder
cd house_price_prediction

# Install dependencies
pip install -r requirements.txt

# Run the script
python house_price_prediction.py
