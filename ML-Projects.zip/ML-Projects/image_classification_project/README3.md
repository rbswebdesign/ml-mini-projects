# MNIST Handwritten Digit Classification using CNN

## 📌 Overview
This project uses a **Convolutional Neural Network (CNN)** to classify handwritten digits from the **MNIST dataset**.  
The model achieves **99.48% training accuracy** and **98.46% validation accuracy**.

---

## 📂 Dataset
The dataset is the **MNIST** dataset, available directly in TensorFlow/Keras.  
- **60,000** training images
- **10,000** test images  
- Each image is **28x28** grayscale.

---

## ⚙️ Model Architecture
1. **Conv2D**: 32 filters, 3x3, ReLU
2. **MaxPooling2D**: 2x2
3. **Conv2D**: 64 filters, 3x3, ReLU
4. **MaxPooling2D**: 2x2
5. **Conv2D**: 128 filters, 3x3, ReLU
6. **MaxPooling2D**: 2x2
7. **Flatten**
8. **Dense**: 512 neurons, ReLU
9. **Dense**: 10 neurons, Softmax (output layer)

---

## 📊 Results
- **Final Training Accuracy:** 99.48%
- **Final Validation Accuracy:** 98.46%

| Epoch | Train Accuracy | Val Accuracy |
|-------|---------------|--------------|
| 1     | ~98%          | ~97%         |
| 15    | 99.48%        | 98.46%       |

---

## 📷 Charts
![Accuracy Chart](mnist_accuracy_chart.png)  
![Loss Chart](mnist_loss_chart.png)

---

## 🚀 How to Run
```bash
pip install tensorflow matplotlib pandas
python mnist_cnn.py
