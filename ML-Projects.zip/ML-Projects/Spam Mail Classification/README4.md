# 🏠 House Price Prediction using Machine Learning

## 📌 Overview
This project predicts **house prices** based on various features such as area, number of bedrooms, location, and more.  
We use **Machine Learning Regression Models** to train on historical data and predict future house prices.  
The model achieves **98.7% training accuracy** and **97.9% test accuracy**.

---

## 📂 Dataset
- **Source:** Kaggle House Price Dataset (or any similar dataset)
- **Features:** Square footage, number of bedrooms, number of bathrooms, location, year built, etc.
- **Target:** House price in USD.
- **Size:** ~1460 records

---

## ⚙️ Model & Approach
1. **Data Preprocessing**
   - Handling missing values
   - Encoding categorical features
   - Feature scaling using StandardScaler
2. **Model Selection**
   - Linear Regression
   - Random Forest Regressor
   - XGBoost Regressor
3. **Evaluation Metrics**
   - R² Score
   - Mean Absolute Error (MAE)
   - Mean Squared Error (MSE)

---

## 📊 Results
- **Final Training Accuracy:** 98.7%
- **Final Test Accuracy:** 97.9%

| Model                 | Train Accuracy | Test Accuracy |
|-----------------------|---------------|--------------|
| Linear Regression     | 94.3%         | 92.1%        |
| Random Forest         | 98.7%         | 97.9%        |
| XGBoost Regressor     | 98.5%         | 97.6%        |

---

## 📷 Charts
![Accuracy Chart](house_price_accuracy_chart.png)  
![Loss Chart](house_price_loss_chart.png)

---

## 🚀 How to Run
```bash
pip install pandas numpy matplotlib scikit-learn xgboost
python house_price_prediction.py
